package com.cmpt_275;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;

public class SettingPane extends JPanel {
    private double xMin, xMax, xStep;
    private double yMin, yMax, yStep;
    private JTextField xMinTF, xMaxTF, xStepTF;
    private JTextField yMinTF, yMaxTF, yStepTF;

    public SettingPane(String mode) {
        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        //setLayout(new GridLayout(0,4));
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new BoxLayout(labelPane,BoxLayout.LINE_AXIS));
        //labelPane.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.black));
        labelPane.setPreferredSize(new Dimension(500, 30));
        JLabel varLabel = new JLabel("Vars");
        varLabel.setHorizontalAlignment(JLabel.CENTER);
        varLabel.setMaximumSize(new Dimension(50,20));
        JLabel minLabel = new JLabel("Min");
        minLabel.setHorizontalAlignment(JLabel.CENTER);
        minLabel.setMaximumSize(new Dimension(100,20));
        JLabel maxLabel = new JLabel("Max");
        maxLabel.setHorizontalAlignment(JLabel.CENTER);
        maxLabel.setMaximumSize(new Dimension(100,20));
        JLabel stepLabel = new JLabel("Step");
        stepLabel.setHorizontalAlignment(JLabel.CENTER);
        stepLabel.setMaximumSize(new Dimension(100,20));
        labelPane.add(varLabel);
        labelPane.add(minLabel);
        labelPane.add(Box.createRigidArea(new Dimension(20,0)));
        labelPane.add(maxLabel);
        labelPane.add(Box.createRigidArea(new Dimension(20,0)));
        labelPane.add(stepLabel);

        JPanel xPane = new JPanel();
        xPane.setLayout(new BoxLayout(xPane,BoxLayout.LINE_AXIS));
        //xPane.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.black));
        xPane.setPreferredSize(new Dimension(500, 30));

        JLabel varX = new JLabel("x");
        varX.setHorizontalAlignment(JLabel.CENTER);
        varX.setMaximumSize(new Dimension(50,20));

        xMinTF = new JTextField();
        xMinTF.setMaximumSize(new Dimension(100,20));

        xMaxTF = new JTextField();
        xMaxTF.setMaximumSize(new Dimension(100,20));

        xStepTF = new JTextField();
        xStepTF.setMaximumSize(new Dimension(100,20));

        xPane.add(varX);
        xPane.add(xMinTF);
        xPane.add(Box.createRigidArea(new Dimension(20,0)));
        xPane.add(xMaxTF);
        xPane.add(Box.createRigidArea(new Dimension(20,0)));
        xPane.add(xStepTF);



        JPanel yPane = new JPanel();
        yPane.setLayout(new BoxLayout(yPane, BoxLayout.LINE_AXIS));
        yPane.setPreferredSize(new Dimension(500, 30));

        JLabel varY = new JLabel("y");
        varY.setHorizontalAlignment(JLabel.CENTER);
        varY.setMaximumSize(new Dimension(50,20));

        yMinTF = new JTextField();
        yMinTF.setMaximumSize(new Dimension(100,20));

        yMaxTF = new JTextField();
        yMaxTF.setMaximumSize(new Dimension(100,20));

        yStepTF = new JTextField();
        yStepTF.setMaximumSize(new Dimension(100,20));

        yPane.add(varY);
        yPane.add(yMinTF);
        yPane.add(Box.createRigidArea(new Dimension(20,0)));
        yPane.add(yMaxTF);
        yPane.add(Box.createRigidArea(new Dimension(20,0)));
        yPane.add(yStepTF);

        switch(mode) {
            case "2D":
                add(labelPane);
                add(xPane);
                break;
            case "3D":
                add(labelPane);
                add(xPane);
                add(yPane);
                break;
            default:
                break;
        }
    }

    public double getXMin() {
        xMin = Double.parseDouble(xMinTF.getText());
        return xMin;
    }

    public double getXMax() {
        xMax = Double.parseDouble(xMaxTF.getText());
        return xMax;
    }

    public double getXStep() {
        xStep = Double.parseDouble(xStepTF.getText());
        return xStep;
    }

    public double getYMin() {
        yMin = Double.parseDouble(yMinTF.getText());
        return yMin;
    }

    public double getYMax() {
        yMax = Double.parseDouble(yMaxTF.getText());
        return yMax;
    }

    public double getYStep() {
        yStep = Double.parseDouble(yStepTF.getText());
        return yStep;
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("SettingPane");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JComponent newContentPane = new SettingPane("3D");
        newContentPane.setOpaque(true);
        frame.setContentPane(newContentPane);

        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

}
