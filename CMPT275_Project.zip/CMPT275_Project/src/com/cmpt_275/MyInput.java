package com.cmpt_275;

import org.nfunk.jep.JEP;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class MyInput extends JPanel implements ActionListener,DocumentListener{
    private ArrayList<JTextField> expressions;
    private ArrayList<MyButton> buttons;
    private ArrayList<JPanel> expWithButtons;
    private ArrayList<Integer> activateExprIndex;
    private MyParser parser;
    private int numOfExp = 0;
    private MyOutput outPane;
    private final int maxExp = 5;
    private boolean mode2D = true;
    private boolean mode3D = false;
    private ArrayList<Integer> plotIndex; // index: plotI, element: expI
    private static int exprNum;
    //private int lastExpr = 0,secondLastExpr = 0;


    public MyInput(String mode, MyOutput out) {
        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS ));
        exprNum = 0;
        //setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.black));
        parser = new MyParser();
        outPane = out;
        JLabel prompt = new JLabel("");

        switch (mode) {
            case "2D":
                mode2D = true;
                mode3D = false;
                parser.addVariable("x",0);
                prompt.setText("2D mode with variable x");
                break;
            case "3D":
                mode2D = false;
                mode3D = true;
                parser.addVariable("x",0);
                parser.addVariable("y",0);
                prompt.setText("3D mode with variables x and y");
                break;
            default:
                break;
        }


        //prompt.setMaximumSize(new Dimension(500,30));
        //prompt.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.black));
        prompt.setAlignmentX(Component.CENTER_ALIGNMENT);


        expressions = new ArrayList<JTextField>(maxExp);
        buttons = new ArrayList<MyButton>(maxExp);
        expWithButtons = new ArrayList<JPanel>(maxExp);

        plotIndex = new ArrayList<Integer>(maxExp);

        activateExprIndex = new ArrayList<Integer>(maxExp);

        add(prompt);
        addExpression();
    }

    public void actionPerformed(ActionEvent e) {
        JTextField exprText = (JTextField)e.getSource();
        //parser.resetVariables();
        String expression = exprText.getText();

        boolean err = parser.hasError(expression);
        if (!err && numOfExp <= maxExp) {
            //outPane.removeAllPlots();
            if (mode2D) {
                if (parser.is2D()) {
                    plot(exprText);
                }
                else
                    JOptionPane.showMessageDialog(null, "Too much variables for 2D");
            }
            if (mode3D) {
                if (parser.is3D()) {
                    plot(exprText);
                }
                else
                    JOptionPane.showMessageDialog(null, "Too much variables for 3D ");

            }
            //System.out.println(activateExprIndex);
//            if(numOfExp > 1) {
////                for(int i = 0; i < buttons.size(); i++) {
////                    buttons.get(i).setEnabled(true);
////                }
//                for(int i = 0; i < activateExprIndex.size(); i++) {
//                    buttons.get(activateExprIndex.get(i)).setEnabled(true);
//                }
//            }
        }

    }

    public void insertUpdate(DocumentEvent e) {
        JTextField exprText = (JTextField)e.getDocument().getProperty("Owner");
        if(exprText != null)
            update(exprText);
    }
    public void removeUpdate(DocumentEvent e) {
        JTextField exprText = (JTextField)e.getDocument().getProperty("Owner");
        if(exprText != null)
            update(exprText);
    }
    public void changedUpdate(DocumentEvent e) {

    }


    private void update(JTextField exprText) {
        String expression = exprText.getText();
        boolean err = parser.hasError(expression);
        if(err) {
            exprText.setForeground(Color.RED);
        }
        else {
            exprText.setForeground(Color.BLACK);
        }
        //outPane.plot(expression);
    }

    private void addExpression() {
        if(numOfExp < maxExp) {
            createExpWithButtons();
            add(expWithButtons.get(exprNum));
            exprNum++;
            numOfExp++;
            //System.out.println(numOfExp);
            revalidate();
        }
    }

    public boolean getMode2D() {
        return mode2D;
    }

    public boolean getMode3D() {
        return mode3D;
    }

    private void plot(JTextField exprText) {
        String expression = exprText.getText();
        int expressionIndex = expressions.indexOf(exprText); //expI

        int oldPlotIndex = plotIndex.indexOf(expressionIndex); //plotI of expI
        if (oldPlotIndex != -1)
            plotIndex.remove(oldPlotIndex);


        int newPlotIndex = -1;
        if(mode2D)
            newPlotIndex = outPane.replot2D(expression, oldPlotIndex);
        if(mode3D)
            newPlotIndex = outPane.replot3D(expression,oldPlotIndex);

        if(newPlotIndex != -1)
            plotIndex.add(newPlotIndex,expressionIndex);

        if(expressionIndex == activateExprIndex.get(activateExprIndex.size()-1))
            addExpression();
        //System.out.println(plotIndex);
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("MyInput");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MyOutput out  = new MyOutput("2D");
        JComponent newContentPane = new MyInput("2D", out);
        newContentPane.setOpaque(true);
        frame.setContentPane(newContentPane);

        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }

    class RemoveListener implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            JButton btn = (JButton)e.getSource();
            int expressionIndex = buttons.indexOf(btn);
            int oldPlotIndex = plotIndex.indexOf(expressionIndex);
            if(oldPlotIndex != -1) {
                expressions.get(expressionIndex).setText("");
                plotIndex.remove(oldPlotIndex);
                if(mode2D)
                    outPane.remove2DPlot(oldPlotIndex);
                if(mode3D)
                    outPane.remove3DPlot(oldPlotIndex);
                if(activateExprIndex.size() > 1) {
                    activateExprIndex.remove(new Integer(expressionIndex));
                    remove(expWithButtons.get(expressionIndex));
                    //System.out.println(activateExprIndex);

                    numOfExp--;
                }
            }

//            if(activateExprIndex.size() > 1) {
//                activateExprIndex.remove(new Integer(expressionIndex));
//                remove(expWithButtons.get(expressionIndex));
//                //System.out.println(activateExprIndex);
//
//                numOfExp--;
//            }
//            if(numOfExp == 1) {
////                for(int i = 0; i < buttons.size(); i++){
////                    buttons.get(i).setEnabled(false);
////                }
//                buttons.get(activateExprIndex.get(0)).setEnabled(false);
//            }

            revalidate();
            repaint();

        }
    }

    private void createExpWithButtons() {
        expWithButtons.add(new JPanel(new FlowLayout()));
        activateExprIndex.add(exprNum);
        expWithButtons.get(exprNum).setMaximumSize(new Dimension(700,50));

        JLabel outputLabel = new JLabel("");
        outputLabel.setVerticalAlignment(JLabel.CENTER);
        if(mode2D)
            outputLabel.setText("y"+exprNum+"= ");
        if(mode3D)
            outputLabel.setText("z"+exprNum+"= ");

        buttons.add(new MyButton());
        buttons.get(exprNum).setVerticalAlignment(MyButton.CENTER);
        buttons.get(exprNum).setIcon(new ImageIcon("src\\Buttons\\Pre\\delete.png"));
        buttons.get(exprNum).setRolloverIcon(new ImageIcon("src\\Buttons\\Cover\\delete_cover.png"));
        buttons.get(exprNum).setPressedIcon(new ImageIcon("src\\Buttons\\Cover\\delete_cover.png"));
        //buttons.get(exprNum).setEnabled(false);

        expressions.add(new JTextField(""));
        expressions.get(exprNum).setPreferredSize(new Dimension(100,20));
        expressions.get(exprNum).getDocument().putProperty("Owner",expressions.get(exprNum));

        expWithButtons.get(exprNum).add(outputLabel);
        expWithButtons.get(exprNum).add(expressions.get(exprNum));
        expWithButtons.get(exprNum).add(buttons.get(exprNum));



        expressions.get(exprNum).addActionListener(this);
        expressions.get(exprNum).getDocument().addDocumentListener(this);
        //buttons[i].addActionListener(new RemoveListener());
        buttons.get(exprNum).addActionListener(new RemoveListener());

//        exprNum++;
    }



}

