package com.cmpt_275;

import javax.swing.*;
import java.awt.*;

public class MyButton extends JButton {
    public MyButton(){
        super();
        setMargin(new Insets(0,0,0,0));
        setContentAreaFilled(false);
        setBorderPainted(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }
}