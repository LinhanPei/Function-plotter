package com.cmpt_275;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;

public class FunctionPlotter extends JPanel{
    private MyInput inputPane;
    private MyOutput outputPane;
    private JPanel leftPane;
    //private MyButton settingButton;
    final private String[] mode = {"2D","3D"};
    private String currentMode = mode[0];
    private Component filler = Box.createVerticalGlue();

    public FunctionPlotter() {
        setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS ));


        outputPane = new MyOutput(currentMode); // 2D mode
        outputPane.setAlignmentY(Component.TOP_ALIGNMENT);
        inputPane = new MyInput(currentMode, outputPane);
        inputPane.setAlignmentY(Component.TOP_ALIGNMENT);
        inputPane.setAlignmentX(Component.CENTER_ALIGNMENT);
//        add(inputPane);
//        add(outputPane);

        MyButton button2D = new MyButton();
        button2D.setIcon(new ImageIcon("src\\Buttons\\Pre\\2d.png"));
        button2D.setRolloverIcon(new ImageIcon("src\\Buttons\\Cover\\2d_cover.png"));
        button2D.setPressedIcon(new ImageIcon("src\\Buttons\\Cover\\2d_cover.png"));
        button2D.setAlignmentY(JComponent.TOP_ALIGNMENT);
        button2D.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!currentMode.equals("2D")) {
                    int choice = JOptionPane.showConfirmDialog(null,"This option will clear your current data.\n\tDo you want to continue?","Warning",JOptionPane.OK_CANCEL_OPTION);
                    if(choice == 0) {
                        leftPane.remove(filler);
                        leftPane.remove(inputPane);
                        remove(outputPane);
                        currentMode = mode[0];
                        outputPane = new MyOutput(currentMode);
                        outputPane.setAlignmentY(Component.TOP_ALIGNMENT);
                        inputPane = new MyInput(currentMode, outputPane);
                        inputPane.setAlignmentY(Component.TOP_ALIGNMENT);
                        inputPane.setAlignmentX(Component.CENTER_ALIGNMENT);
                        leftPane.add(inputPane);
                        leftPane.add(filler);
                        add(outputPane);
                        revalidate();
                        repaint();
                    }
                }
            }
        });

        MyButton button3D = new MyButton();
        button3D.setIcon(new ImageIcon("src\\Buttons\\Pre\\3d.png"));
        button3D.setRolloverIcon(new ImageIcon("src\\Buttons\\Cover\\3d_cover.png"));
        button3D.setPressedIcon(new ImageIcon("src\\Buttons\\Cover\\3d_cover.png"));
        button3D.setAlignmentY(JComponent.TOP_ALIGNMENT);
        button3D.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!currentMode.equals("3D")) {
                    int choice = JOptionPane.showConfirmDialog(null,"This option will clear your current data.\nDo you want to continue?","Warning",JOptionPane.OK_CANCEL_OPTION);
                    if(choice == 0) {
                        leftPane.remove(filler);
                        leftPane.remove(inputPane);
                        remove(outputPane);
                        currentMode = mode[1];
                        outputPane = new MyOutput(currentMode);
                        outputPane.setAlignmentY(Component.TOP_ALIGNMENT);
                        inputPane = new MyInput(currentMode, outputPane);
                        inputPane.setAlignmentY(Component.TOP_ALIGNMENT);
                        inputPane.setAlignmentX(Component.CENTER_ALIGNMENT);
                        leftPane.add(inputPane);
                        leftPane.add(filler);
                        add(outputPane);
                        revalidate();
                        repaint();
                    }
                }
            }
        });

        MyButton settingButton = new MyButton();
        settingButton.setIcon(new ImageIcon("src\\Buttons\\Pre\\setting.png"));
        settingButton.setRolloverIcon(new ImageIcon("src\\Buttons\\Cover\\setting_cover.png"));
        settingButton.setPressedIcon(new ImageIcon("src\\Buttons\\Cover\\setting_cover.png"));
        settingButton.setAlignmentY(JComponent.TOP_ALIGNMENT);
        settingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SettingPane setting = new SettingPane(currentMode);
                int result = JOptionPane.showConfirmDialog(null,setting,"Setting",JOptionPane.OK_CANCEL_OPTION);
                if(result == 0) {
                    if(currentMode.equals("2D")) {
                        try{
                            if (outputPane.validParameters(setting.getXMin(), setting.getXMax(), setting.getXStep())) {
                                outputPane.setXMin(setting.getXMin());
                                outputPane.setXMax(setting.getXMax());
                                outputPane.setXStep(setting.getXStep());
                            } else {
                                JOptionPane.showMessageDialog(null, "Invalid parameters.");
                            }
                        }
                        catch(Exception ex) {
                            JOptionPane.showMessageDialog(null, "Invalid parameters.");
                        }
                    }
                    if(currentMode.equals("3D")) {
                        try{
                            if (outputPane.validParameters(setting.getXMin(), setting.getXMax(), setting.getXStep()) &&
                                    outputPane.validParameters(setting.getYMin(), setting.getYMax(), setting.getYStep())) {
                                outputPane.setXMin(setting.getXMin());
                                outputPane.setXMax(setting.getXMax());
                                outputPane.setXStep(setting.getXStep());
                                outputPane.setYMin(setting.getYMin());
                                outputPane.setYMax(setting.getYMax());
                                outputPane.setYStep(setting.getYStep());
                            } else {
                                JOptionPane.showMessageDialog(null, "Invalid parameters.");
                            }
                        }
                        catch(Exception ex) {
                            JOptionPane.showMessageDialog(null, "ERROR");
                        }
//                        if (outputPane.validParameters(setting.getXMin(), setting.getXMax(), setting.getXStep()) &&
//                        outputPane.validParameters(setting.getYMin(), setting.getYMax(), setting.getYStep())) {
//                            outputPane.setXMin(setting.getXMin());
//                            outputPane.setXMax(setting.getXMax());
//                            outputPane.setXStep(setting.getXStep());
//                            outputPane.setYMin(setting.getYMin());
//                            outputPane.setYMax(setting.getYMax());
//                            outputPane.setYStep(setting.getYStep());
//                        } else {
//                            JOptionPane.showMessageDialog(null, "Invalid parameters.");
//                        }
                    }
                }
            }
        });



        JPanel toolPane = new JPanel(new FlowLayout());
        toolPane.setMaximumSize(new Dimension(500,30));
        toolPane.setAlignmentX(Component.CENTER_ALIGNMENT);
        //toolPane.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.black));
        toolPane.add(button2D);
        toolPane.add(button3D);
        toolPane.add(settingButton);

        leftPane = new JPanel();
        leftPane.setLayout(new BoxLayout(leftPane, BoxLayout.PAGE_AXIS));
        leftPane.setAlignmentY(Component.TOP_ALIGNMENT);
        //leftPane.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.black));

        leftPane.add(toolPane);
        leftPane.add(inputPane);
        leftPane.add(filler);

        add(leftPane);
        add(outputPane);
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("FunctionPlotter");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JComponent newContentPane = new FunctionPlotter();
        newContentPane.setOpaque(true);
        frame.setContentPane(newContentPane);

        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}
