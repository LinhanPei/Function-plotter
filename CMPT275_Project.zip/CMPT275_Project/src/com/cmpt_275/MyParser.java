package com.cmpt_275;

import org.nfunk.jep.JEP;
import org.nfunk.jep.SymbolTable;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Enumeration;

public class MyParser {
    private JEP parser;
    private ArrayList<String> defaultSymbols;

    public MyParser() {
        // Init Parser
        parser = new JEP();

        // Allow implicit multiplication
        parser.setImplicitMul(true);

        // Load the standard functions
        parser.addStandardFunctions();

        // Load the standard constants, and complex variables/functions
        parser.addStandardConstants();
        parser.addComplex();

        SymbolTable table = parser.getSymbolTable();
        Enumeration names = table.keys();

        defaultSymbols = new ArrayList<String>();
        while (names.hasMoreElements())
            defaultSymbols.add((String)names.nextElement());


        // Add and initialize x to 0
        //parser.addVariable("x", 0);
        //parser.setAllowUndeclared(true);
    }
    public MyParser(String expression) {
        // Init Parser
        parser = new JEP();

        // Allow implicit multiplication
        parser.setImplicitMul(true);

        // Load the standard functions
        parser.addStandardFunctions();

        // Load the standard constants, and complex variables/functions
        parser.addStandardConstants();
        parser.addComplex();

        SymbolTable table = parser.getSymbolTable();
        Enumeration names = table.keys();
        defaultSymbols = new ArrayList<String>();
        while (names.hasMoreElements())
            defaultSymbols.add((String)names.nextElement());


        // Add and initialize x to 0
        //parser.addVariable("x", 0);
        parser.setAllowUndeclared(true);

        parser.parseExpression(expression);
    }

    public boolean hasError(String expression) {
        parser.parseExpression(expression);
        return parser.hasError();
    }

    public Double addVariable(String var, double val) {
        return parser.addVariable(var, val);
    }
    public double getValue() {
        return parser.getValue();
    }

    public ArrayList<String> getVariables() {
        ArrayList<String> vars = new ArrayList<String>();
        SymbolTable table = parser.getSymbolTable();
        Enumeration names = table.keys();
        while (names.hasMoreElements()) {
            String var = (String)names.nextElement();
            if(!defaultSymbols.contains(var)) {
                vars.add(var);
            }
        }
        return vars;
    }

    public boolean is2D() {
        return numOfVars() <= 1;
    }

    public boolean is3D() {
        return numOfVars() <= 2;
    }

    public int numOfVars() {
        ArrayList<String> vars = getVariables();
        return vars.size();
    }
    public void resetVariables() {
        SymbolTable table = parser.getSymbolTable();
        Enumeration names = table.keys();
        while (names.hasMoreElements()) {
            String var = (String)names.nextElement();
            if(!defaultSymbols.contains(var)) {
                table.remove(var);
            }
        }
    }

}

