package com.cmpt_275;

import org.math.plot.Plot2DPanel;
import org.math.plot.Plot3DPanel;
import org.math.plot.PlotPanel;
import org.math.plot.utils.Array;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MyOutput extends JPanel {

    private JTextField out;
    private MyParser parser;
    private ArrayList<String> vars;
    private ArrayList<ArrayList<Double>> values;
    private ArrayList<Double> out2D;
    private ArrayList<ArrayList<Double>> out3D;
    private Plot2DPanel pane2D;
    private Plot3DPanel pane3D;
    private int totalPlots;
    private final static Color[] COLORLIST = {Color.BLUE, Color.RED, Color.GREEN, Color.YELLOW, Color.ORANGE, Color.PINK, Color.CYAN, Color.MAGENTA};
    private int currentColor = 0;

    //double start = 0, end = 6, step = 0.1;
    double xMin = 0, xMax = 6, xStep = 0.1;
    double yMin = 0, yMax = 6, yStep = 0.1;
    public MyOutput(String mode) {
        setLayout(new BorderLayout());
        String var0 = "x";
        String var1 = "y";
        vars = new ArrayList<String>();
        resetValues();
        switch (mode) {
            case "2D":
                parser = new MyParser();
                parser.addVariable(var0,0);
                vars.add(var0);
                pane2D = new Plot2DPanel();
                pane2D.setLegendOrientation(PlotPanel.SOUTH);
                add(pane2D);
                break;
            case "3D":
                parser = new MyParser();
                parser.addVariable(var0,0);
                parser.addVariable(var1,0);
                vars.add(var0);
                vars.add(var1);
                pane3D = new Plot3DPanel();
                pane3D.setLegendOrientation(PlotPanel.SOUTH);
                add(pane3D);
                break;
            default:
                break;
        }
//        out = new JTextField("");
//        add(out);
    }

    public int plot2D(String expression) {
//        parser = new MyParser(expression);
//        vars = parser.getVariables();
        if(parser.hasError(expression))
            return -1;
        //System.out.println(vars);
        //setValues(1);
        //resetValues();
        if(validParameters(xMin,xMax,xStep))
            setXValues(xMin, xMax, xStep);
        else {
            JOptionPane.showMessageDialog(null,"Invalid parameters.");
            return -1;
        }
        //System.out.println(values);
        try {
            calculate2DOutput();
            //System.out.println(out2D);
        }
        catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null,"Some points are undefined.\nPlease set your domain in Setting.");
            return -1;
        }

        double[] x = new double[values.get(0).size()];
        double[] y = new double[out2D.size()];
        for(int i = 0; i < x.length; i++) {
            x[i] = values.get(0).get(i).doubleValue();
            y[i] = out2D.get(i).doubleValue();
        }

        return pane2D.addLinePlot(expression,x,y);

    }

    public int plot2D(String expression, Color c) {
//        parser = new MyParser(expression);
//        vars = parser.getVariables();
        //System.out.println(vars);
        if(parser.hasError(expression))
            return -1;
        //setValues(1);
        //resetValues();
        if(validParameters(xMin,xMax,xStep))
            setXValues(xMin, xMax, xStep);
        else {
            JOptionPane.showMessageDialog(null,"Invalid parameters.");
            return -1;
        }

        //System.out.println(values);
        try {
            calculate2DOutput();
            //System.out.println(out2D);
        }
        catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null,"Some points are undefined.\nPlease set your domain in Setting.");
            return -1;
        }

        double[] x = new double[values.get(0).size()];
        double[] y = new double[out2D.size()];
        for(int i = 0; i < x.length; i++) {
            x[i] = values.get(0).get(i).doubleValue();
            y[i] = out2D.get(i).doubleValue();
        }

        return pane2D.addLinePlot(expression,c,x,y);
    }

    public int plot3D(String expression) {
//        parser = new MyParser(expression);
//        vars = parser.getVariables();
        if(parser.hasError(expression))
            return -1;
        //System.out.println(vars);
        //setValues(2);
        //resetValues();
        if(validParameters(xMin,xMax,xStep) && validParameters(yMin,yMax,yStep)) {
            setXValues(xMin, xMax, xStep);
            setYValues(yMin, yMax, yStep);
        }
        else {
            JOptionPane.showMessageDialog(null,"Invalid parameters.");
            return -1;
        }
        //System.out.println(values);
        try {
            calculate3DOutput();
        }
        catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null,"Some points are undefined.\nPlease set your domain in Setting.");
            return -1;
        }
        //System.out.println(out2D);
        double[] x = new double[values.get(0).size()];
        double[] y = new double[values.get(1).size()];
        double[][] z = new double[values.get(1).size()][values.get(0).size()];
        for(int i = 0; i < x.length; i++) {
            x[i] = values.get(0).get(i).doubleValue();
            for(int j = 0; j < y.length; j++) {
                y[j] = values.get(1).get(j).doubleValue();
                z[j][i] = out3D.get(i).get(j).doubleValue();
            }
        }

        return pane3D.addGridPlot(expression,x,y,z);
    }

    public int plot3D(String expression, Color c) {
//        parser = new MyParser(expression);
//        vars = parser.getVariables();
        if(parser.hasError(expression))
            return -1;
        //System.out.println(vars);
        //setValues(2);
        //resetValues();
        if(validParameters(xMin,xMax,xStep) && validParameters(yMin,yMax,yStep)) {
            setXValues(xMin, xMax, xStep);
            setYValues(yMin, yMax, yStep);
        }
        else {
            JOptionPane.showMessageDialog(null,"Invalid parameters.");
            return -1;
        }
        //System.out.println(values);
        try {
            calculate3DOutput();
        }
        catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null,"Some points are undefined.\nPlease set your domain in Setting.");
            return -1;
        }
        //System.out.println(out2D);
        double[] x = new double[values.get(0).size()];
        double[] y = new double[values.get(1).size()];
        double[][] z = new double[values.get(1).size()][values.get(0).size()];
        for(int i = 0; i < x.length; i++) {
            x[i] = values.get(0).get(i).doubleValue();
            for(int j = 0; j < y.length; j++) {
                y[j] = values.get(1).get(j).doubleValue();
                z[j][i] = out3D.get(i).get(j).doubleValue();
            }
        }

        return pane3D.addGridPlot(expression,c,x,y,z);
    }

//    private void setValues(int dimension) {
//        values = new ArrayList<ArrayList<Double>>();
//        for(int i = 0; i < dimension; i++) {
//            ArrayList<Double> domain = setDomain(0,6,0.1);
//            values.add(domain);
//        }
//    }

    private void resetValues() {
        values = new ArrayList<ArrayList<Double>>();
        values.add(new ArrayList<Double>());
        values.add(new ArrayList<Double>());
    }
    public void setXValues(double start, double end, double step) {
        ArrayList<Double> domain = setDomain(start, end, step);
        values.set(0, domain);
    }
    public void setYValues(double start, double end, double step) {
        ArrayList<Double> domain = setDomain(start, end, step);
        values.set(1, domain);
    }

    private ArrayList<Double> setDomain(double start, double end, double step) {
        ArrayList<Double> domain = new ArrayList<Double>();

        for(double i = start; i < end; i += step) {
            domain.add(i);
        }
        return domain;
    }
//    private ArrayList<Double> setXDomain(double start, double end, double step) {
//        ArrayList<Double> domain = new ArrayList<Double>();
//
//        for(double i = start; i < end; i += step) {
//            domain.add(i);
//        }
//        return domain;
//    }

//    private ArrayList<Double> setYDomain(double start, double end, double step) {
//        ArrayList<Double> domain = new ArrayList<Double>();
//
//        for(double i = start; i < end; i += step) {
//            domain.add(i);
//        }
//        return domain;
//    }

    private void calculate2DOutput() throws NumberFormatException{
        out2D = new ArrayList<Double>();
        for(int i = 0; i < values.get(0).size(); i++) {
            if(vars.size() == 1)
                parser.addVariable(vars.get(0), values.get(0).get(i));

            double value = parser.getValue();
            if(Double.isInfinite(value) || Double.isNaN(value)) {
                //throw new NumberFormatException();
                values.get(0).remove(i);
                i--;
            }
            else
                out2D.add(value);
        }
    }

    private void calculate3DOutput() throws NumberFormatException{
        out3D = new ArrayList<ArrayList<Double>>();

        boolean notANum = false;
        for(int i = 0; i < values.get(0).size(); i++) {
            ArrayList<Double> temp = new ArrayList<Double>();
            parser.addVariable(vars.get(0), values.get(0).get(i));
            for(int j = 0; j < values.get(1).size(); j++) {
//                if(vars.size() == 2) {
//                    parser.addVariable(vars.get(0), values.get(0).get(i));
//                    parser.addVariable(vars.get(1), values.get(1).get(j));
//                }
//                else if(vars.size() == 1)
//                    parser.addVariable(vars.get(0), values.get(0).get(i));
                parser.addVariable(vars.get(1), values.get(1).get(j));

                double value = parser.getValue();
                if(Double.isNaN(value) || Double.isInfinite(value))
                    throw new NumberFormatException();
                else {
                        temp.add(value);
                }

            }
            out3D.add(temp);
        }

    }

    public void remove2DPlot(int index) {
        if(index == -1)
            return;
        pane2D.removePlot(index);

    }

    public void remove3DPlot(int index) {
        if(index == -1)
            return;
        pane3D.removePlot(index);
    }

    public int replot2D(String expression, int index) {
        if(index != -1) {
            Color c = pane2D.getPlot(index).getColor();
            remove2DPlot(index);
            return plot2D(expression, c);
        }
        else
            return plot2D(expression, getNewColor());
    }

    public int replot3D(String expression, int index) {
        if(index != -1) {
            Color c = pane3D.getPlot(index).getColor();
            remove3DPlot(index);
            return plot3D(expression, c);
        }
        else
            return plot3D(expression, getNewColor());
    }

    private Color getNewColor() {
        Color c = COLORLIST[currentColor];
        currentColor++;
        currentColor = currentColor % COLORLIST.length;
        return c;
    }

    public void setXMin(double min) {
        xMin = min;
    }

    public void setXMax(double max) {
        xMax = max;
    }

    public void setXStep(double step) {
        xStep = step;
    }

    public void setYMin(double min) {
        yMin = min;
    }

    public void setYMax(double max) {
        yMax = max;
    }

    public void setYStep(double step) {
        yStep = step;
    }

    public boolean validParameters(double start, double end, double step) {
        boolean isNum =  Double.isFinite(start) && Double.isFinite(end) && Double.isFinite(step);
        boolean validRelation = start < end && step > 0;
        return isNum && validRelation;
    }
}
